// seven.h
#ifndef SEVEN_H
#define SEVEN_H

void seven_segment_init(void);
void display_digit(int num);
void display_off(void);

#endif
